package yyg.Reference.external;

public class PlayerGameInfo {

	enum Location {
		MAP_1, MAP_2, MAP_3, MAP_4, MAP_5
	};

	enum Status {
		IDLE, BATTLE, DEAD
	};
}
